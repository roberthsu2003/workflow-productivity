@echo off
chcp 65001 >nul
set /p XLSX=請輸入素材總表檔名（例 無紙化流程_素材總表.xlsx）：
set /p DFROM=申報期間起日（例 2026-11-01）：
set /p DTO=申報期間迄日（例 2026-12-31）：
python vat_export.py --xlsx "%XLSX%" --from %DFROM% --to %DTO% --out output_vat
pause
