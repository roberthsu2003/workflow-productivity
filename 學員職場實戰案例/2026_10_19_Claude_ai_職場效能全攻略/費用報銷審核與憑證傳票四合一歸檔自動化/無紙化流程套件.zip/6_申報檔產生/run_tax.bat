@echo off
chcp 65001 >nul
set /p DATADIR=請輸入薪資檔資料夾（例 data）：
set /p YEAR=請輸入給付年度（西元，例 2026）：
python tax_export.py --data "%DATADIR%" --year %YEAR% --out output_tax
pause
