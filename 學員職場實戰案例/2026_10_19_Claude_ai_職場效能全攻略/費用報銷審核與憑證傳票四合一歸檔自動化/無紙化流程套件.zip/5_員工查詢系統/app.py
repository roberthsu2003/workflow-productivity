# -*- coding: utf-8 -*-
"""員工自助查詢系統（原型）：薪資明細下載（加密 PDF）、特休餘額、請假紀錄。
執行：python app.py   （正式環境請放在公司內網或 VPN 後面，並使用 HTTPS 反向代理，詳見說明）
環境變數：HR_DATA_DIR（資料夾，預設 ./data）、HR_FONT（中文字型檔）、HR_SECRET_KEY、HR_HTTPS=1
"""
import os, re, io, time, hmac, secrets, datetime
from flask import Flask, request, session, redirect, url_for, render_template_string, send_file, abort
import packet as P
import hrdata, payslip, vault

BASE = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("HR_DATA_DIR", os.path.join(BASE, "data"))
AUDIT = os.path.join(BASE, "audit.log")
MAX_FAIL, LOCK_SEC, IDLE_SEC = 5, 15 * 60, 15 * 60
fails = {}   # {員編: (次數, 首次失敗時間)}

app = Flask(__name__)
app.secret_key = os.environ.get("HR_SECRET_KEY") or secrets.token_hex(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  SESSION_COOKIE_SECURE=os.environ.get("HR_HTTPS") == "1",
                  PERMANENT_SESSION_LIFETIME=datetime.timedelta(seconds=IDLE_SEC), SESSION_REFRESH_EACH_REQUEST=True)
P.register_font(os.environ.get("HR_FONT"))

def audit(empid, action):
    with open(AUDIT, "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now():%Y-%m-%d %H:%M:%S}\t{empid}\t{action}\t{request.remote_addr}\n")

@app.after_request
def headers(r):
    r.headers.update({"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
                      "Referrer-Policy": "no-referrer", "Content-Security-Policy": "default-src 'self'; style-src 'unsafe-inline'"})
    return r

def latest():
    months = hrdata.list_months(DATA_DIR)
    return months, (hrdata.load_employees(hrdata.month_path(DATA_DIR, months[0])) if months else {})

CSS = """body{font-family:'Microsoft JhengHei',sans-serif;max-width:860px;margin:24px auto;padding:0 14px;color:#222}
h1{color:#1F4E79}table{border-collapse:collapse;width:100%;margin:8px 0}td,th{border:1px solid #ccc;padding:6px 8px;text-align:left}
th{background:#DEEAF6}.card{border:1px solid #ccc;border-radius:8px;padding:12px 16px;margin:12px 0}.big{font-size:28px;color:#1F4E79}
input{padding:8px;margin:4px 0;width:260px}button,a.btn{padding:8px 16px;background:#1F4E79;color:#fff;border:0;border-radius:4px;text-decoration:none}
.err{color:#b00}.small{color:#777;font-size:13px}"""

LOGIN = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>員工自助查詢</title><style>{{css}}</style>
<h1>員工自助查詢系統</h1><p class=small>可查詢薪資明細、特別休假餘額與請假紀錄。請使用員工編號與身分證字號登入。</p>
{% if err %}<p class=err>{{err}}</p>{% endif %}
<form method=post><input type=hidden name=csrf value="{{csrf}}">
<div><input name=empid placeholder="員工編號" autocomplete=username required></div>
<div><input name=idno type=password placeholder="身分證字號" autocomplete=current-password required></div>
<button>登入</button></form>"""

HOME = """<!doctype html><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1"><title>員工自助查詢</title><style>{{css}}</style>
<h1>{{rec.name}}　您好</h1><p class=small>員工編號 {{rec.empid}}　<a href="{{url_for('logout')}}">登出</a>（閒置 15 分鐘自動登出）</p>
<div class=card><b>特別休假（曆年制）</b>{% if lv %}<p>本年度應有 <b>{{'%g'%lv.entitled}}</b> 日（依年資按比例）　上年度遞延 <b>{{'%g'%lv.carry_in}}</b> 日　已休 <b>{{'%g'%lv.used}}</b> 日　剩餘 <span class=big>{{'%g'%lv.remain}}</span> 日</p>
<p class=small>已休僅計入主管已確認的請假。年度終結（12/31）仍未休的日數，除經您提出並同意遞延至次年外，公司將折算工資於次年1月薪資發給；遞延日數於次年度終結仍未休完亦會折發工資。</p>
{% if lv.settle %}<p>本次{{lv.settle}}：折發 {{'%g'%lv.settle_days}} 日，工資 NT$ {{'{:,.0f}'.format(lv.settle_amount)}}</p>{% endif %}{% else %}<p>尚無資料</p>{% endif %}</div>
<div class=card><b>薪資明細（下載為加密 PDF，開啟密碼為您的身分證字號）</b><table><tr><th>月份</th><th>下載</th></tr>
{% for ym in months %}<tr><td>{{label(ym)}}</td><td><a class=btn href="{{url_for('slip',ym=ym)}}">下載</a></td></tr>{% endfor %}</table></div>
<div class=card><b>年度薪資所得統計（供報稅參考，加密 PDF，密碼同上）</b><table><tr><th>年度</th><th>下載</th></tr>
{% for y in years %}<tr><td>{{y}} 年</td><td><a class=btn href="{{url_for('annual_pdf',year=y)}}">下載</a></td></tr>{% endfor %}</table></div>
<div class=card><b>{{year}} 年請假累計</b>{% if lv and lv.types %}<table><tr><th>假別</th><th>已休日數</th></tr>{% for k,v in lv.types %}<tr><td>{{k}}</td><td>{{'%g'%v}}</td></tr>{% endfor %}</table>
<p class=small>病假剩餘 {{'%g'%lv.sick_remain}} 日（以 30 日計）；事假剩餘 {{'%g'%lv.pers_remain}} 日（以 14 日計）。</p>{% else %}<p>目前沒有已確認的請假。</p>{% endif %}</div>
<div class=card><b>請假紀錄</b>{% if rec.records %}<table><tr><th>編號</th><th>假別</th><th>起</th><th>迄</th><th>日數</th><th>職務代理人</th><th>主管確認</th></tr>
{% for x in rec.records %}<tr><td>{{x.id}}</td><td>{{x.type}}</td><td>{{x.start}}</td><td>{{x.end}}</td><td>{{'%g'%x.days}}</td><td>{{x.agent}}</td><td>{{x.status}}</td></tr>{% endfor %}</table>{% else %}<p>沒有請假紀錄。</p>{% endif %}</div>"""

def csrf():
    if "csrf" not in session: session["csrf"] = secrets.token_hex(16)
    return session["csrf"]

@app.route("/login", methods=["GET", "POST"])
def login():
    err = ""
    if request.method == "POST":
        if not hmac.compare_digest(request.form.get("csrf", ""), session.get("csrf", "x")):
            abort(400)
        eid = request.form.get("empid", "").strip(); idno = request.form.get("idno", "").strip().upper()
        n, t0 = fails.get(eid, (0, 0))
        if n >= MAX_FAIL and time.time() - t0 < LOCK_SEC:
            audit(eid, "LOCKED"); err = "登入失敗次數過多，請 15 分鐘後再試或洽人資。"
        else:
            if n >= MAX_FAIL: fails.pop(eid, None); n = 0
            _, emps = latest(); rec = emps.get(eid)
            ok = bool(rec and rec["idno"] and hmac.compare_digest(rec["idno"], idno))
            if ok:
                fails.pop(eid, None); session.clear(); session["empid"] = eid; session.permanent = True
                audit(eid, "LOGIN"); return redirect(url_for("home"))
            fails[eid] = (n + 1, t0 or time.time()); audit(eid, "LOGIN_FAIL"); err = "員工編號或身分證字號錯誤。"
    return render_template_string(LOGIN, css=CSS, err=err, csrf=csrf())

@app.route("/logout")
def logout():
    audit(session.get("empid", "-"), "LOGOUT"); session.clear(); return redirect(url_for("login"))

def current():
    eid = session.get("empid")
    if not eid: return None
    _, emps = latest(); return emps.get(eid)

@app.route("/")
def home():
    rec = current()
    if not rec: return redirect(url_for("login"))
    months, _ = latest()
    audit(rec["empid"], "VIEW")
    years = sorted({m[:4] for m in months}, reverse=True)
    return render_template_string(HOME, css=CSS, rec=rec, lv=rec.get("leave"), months=months, years=years, label=hrdata.ym_label, year=datetime.date.today().year)

@app.route("/slip/<ym>")
def slip(ym):
    rec = current()
    if not rec: return redirect(url_for("login"))
    path = hrdata.month_path(DATA_DIR, ym)
    if not path: abort(404)
    r = hrdata.load_employees(path).get(rec["empid"])      # 只取登入者本人的資料
    if not r: abort(404)
    data = payslip.make_payslip_bytes(r, ym, r["idno"])
    audit(rec["empid"], f"DOWNLOAD_{ym}")
    return send_file(io.BytesIO(data), mimetype="application/pdf", as_attachment=True, download_name=f"薪資明細_{rec['empid']}_{ym}.pdf")

@app.route("/annual/<year>")
def annual_pdf(year):
    rec = current()
    if not rec: return redirect(url_for("login"))
    if not re.fullmatch(r"\d{4}", year): abort(404)
    e = hrdata.annual(DATA_DIR, year).get(rec["empid"])    # 只取登入者本人
    if not e: abort(404)
    e["empid"] = rec["empid"]
    data = payslip.make_annual_bytes(e, year, rec.get("leave"), rec["idno"])
    audit(rec["empid"], f"DOWNLOAD_ANNUAL_{year}")
    return send_file(io.BytesIO(data), mimetype="application/pdf", as_attachment=True, download_name=f"年度薪資所得統計_{rec['empid']}_{year}.pdf")

def unlock_and_check():
    """啟動時由您親自輸入通關密語；密語只留在記憶體，不寫入檔案、環境變數或稽核紀錄。"""
    plain = [f for f in os.listdir(DATA_DIR) if re.fullmatch(r"薪資_\d{6}\.xlsx", f)]
    if plain: print("警告：發現未加密的薪資檔，請用 vault.py 加密後刪除原檔：", ", ".join(plain))
    hrdata.set_passphrase(vault.ask_password(prompt="請輸入通關密語（只有您知道，伺服器不會儲存）："))
    months = hrdata.list_months(DATA_DIR)
    if not months: raise SystemExit("data 資料夾內沒有薪資檔")
    try:
        hrdata.load_employees(hrdata.month_path(DATA_DIR, months[0]))
    except Exception:
        raise SystemExit("通關密語錯誤或檔案損毀")
    print("已解鎖（資料只存在記憶體）。")

if __name__ == "__main__":
    unlock_and_check()
    host, port = os.environ.get("HR_HOST", "127.0.0.1"), int(os.environ.get("HR_PORT", "8000"))
    cert, key = os.environ.get("HR_CERT"), os.environ.get("HR_KEY")
    if cert and key:      # 由本程式直接提供 HTTPS，加密連線的終點在您的電腦，MIS 的設備看不到明文
        from cheroot.wsgi import Server
        from cheroot.ssl.builtin import BuiltinSSLAdapter
        srv = Server((host, port), app); srv.ssl_adapter = BuiltinSSLAdapter(cert, key)
        try: srv.start()
        except KeyboardInterrupt: srv.stop()
    else:
        print("提醒：未設定 HR_CERT／HR_KEY，目前為未加密連線，僅供測試。")
        app.run(host=host, port=port)
