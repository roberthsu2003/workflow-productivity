# -*- coding: utf-8 -*-
"""薪資明細單 PDF 產生與加密（開啟密碼＝員工身分證字號）。
批次：python payslip.py --xlsx 薪資_202610.xlsx --out 輸出資料夾 [--font 字型檔]
"""
import io, os, re, argparse, secrets
from pypdf import PdfReader, PdfWriter
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Spacer
from reportlab.platypus import SimpleDocTemplate
import packet as P
import hrdata

COMPANY = "文創科技股份有限公司"

def _fmt(v):
    return f"{int(round(v)):,}" if v else "-"

def make_payslip_bytes(rec, ym, password, company=COMPANY):
    S = P.styles()
    add = [["項目", "金額"]] + [[k, _fmt(v)] for k, v in rec["add"] if v]
    sub = [["項目", "金額"]] + [[k, _fmt(v)] for k, v in rec["sub"] if v]
    add.append(["工資總額", _fmt(rec["add_total"])]); sub.append(["扣除項目合計", _fmt(rec["sub_total"])])
    story = [Paragraph(f"薪資明細單　{hrdata.ym_label(ym)}", S["h1"]),
             Paragraph(f"{company}　員工編號：{rec['empid']}　姓名：{rec['name']}", S["sub"]), Spacer(1, 8),
             Paragraph("加項（工資各項目）", S["body"]), Spacer(1, 3), P.grid(add, [70*mm, 40*mm]), Spacer(1, 8),
             Paragraph("扣除項目（依法令規定或勞雇雙方約定）", S["body"]), Spacer(1, 3), P.grid(sub, [70*mm, 40*mm]), Spacer(1, 8),
             P.grid([["實際發給金額", _fmt(rec["net"])], ["本月加班時數", f"{rec['ot_hours']:g}"], ["本月請假日數", f"{rec['leave_days']:g}"]],
                    [70*mm, 40*mm], header=False)]
    lv = rec.get("leave")
    if lv:
        story += [Spacer(1, 8), Paragraph(f"特別休假（曆年制）：本年度可休 {lv['total']:g} 日（含上年度遞延 {lv['carry_in']:g} 日），已休 {lv['used']:g} 日，剩餘 {lv['remain']:g} 日。", S["body"])]
    story += [Spacer(1, 10), Paragraph("本明細依勞動基準法第23條提供，請妥善保管；如有疑問請洽人資或財務。", S["sub"])]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=P.A4, leftMargin=18*mm, rightMargin=18*mm, topMargin=18*mm, bottomMargin=20*mm).build(story)
    buf.seek(0)
    w = PdfWriter()
    for pg in PdfReader(buf).pages: w.add_page(pg)
    w.add_metadata({"/Title": f"薪資明細單 {rec['empid']} {ym}"})
    w.encrypt(user_password=password, owner_password=secrets.token_hex(16), algorithm="AES-256")
    out = io.BytesIO(); w.write(out); return out.getvalue()

def make_annual_bytes(e, year, lv, password, company=COMPANY):
    S = P.styles(); t = e["total"]
    rows = [["項目", "金額"]] + [[k, _fmt(t.get(k, 0))] for k in
        ["薪資所得(應稅)", "其他兼職薪資", "給付總額(申報)", "扣繳稅額", "給付淨額", "免稅伙食費", "免稅加班費", "未休假薪資", "資遣費", "補充保費代扣", "勞退自願提繳", "勞保自付", "健保自付"]]
    story = [Paragraph(f"{year} 年度薪資所得及扣繳統計", S["h1"]),
             Paragraph(f"{company}　員工編號：{e.get('empid','')}　姓名：{e['name']}　給付月數：{t.get('給付月數',0):g}", S["sub"]), Spacer(1, 8),
             P.grid(rows, [70*mm, 40*mm])]
    if lv:
        story += [Spacer(1, 10), Paragraph("特別休假年度結算（曆年制）", S["body"]), Spacer(1, 3),
                  P.grid([["本年度應有（按比例）", f"{lv['entitled']:g} 日"], ["上年度遞延", f"{lv['carry_in']:g} 日"], ["已休", f"{lv['used']:g} 日"],
                          ["剩餘", f"{lv['remain']:g} 日"], ["年度終結未休折發工資", _fmt(lv['settle_amount'])]], [70*mm, 40*mm], header=False)]
    story += [Spacer(1, 10), Paragraph("本統計供報稅參考，正式以公司開立之各類所得扣繳憑單為準；免稅項目為簡化計算，如有疑問請洽財務。", S["sub"])]
    buf = io.BytesIO()
    SimpleDocTemplate(buf, pagesize=P.A4, leftMargin=18*mm, rightMargin=18*mm, topMargin=18*mm, bottomMargin=20*mm).build(story); buf.seek(0)
    w = PdfWriter()
    for pg in PdfReader(buf).pages: w.add_page(pg)
    w.encrypt(user_password=password, owner_password=secrets.token_hex(16), algorithm="AES-256")
    out = io.BytesIO(); w.write(out); return out.getvalue()

def batch(xlsx, outdir, font=None):
    P.register_font(font)
    m = re.search(r"(\d{6})", os.path.basename(xlsx)); ym = m.group(1) if m else "000000"
    os.makedirs(outdir, exist_ok=True); n = 0
    for eid, rec in hrdata.load_employees(xlsx).items():
        if not rec["idno"]:
            print("略過（缺身分證字號）：", eid); continue
        path = os.path.join(outdir, f"{eid}_{rec['name']}_{ym}.pdf")
        open(path, "wb").write(make_payslip_bytes(rec, ym, rec["idno"])); n += 1
    print(f"完成：{n} 份，輸出到 {outdir}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--xlsx", required=True); ap.add_argument("--out", required=True); ap.add_argument("--font")
    a = ap.parse_args(); batch(a.xlsx, a.out, a.font)
