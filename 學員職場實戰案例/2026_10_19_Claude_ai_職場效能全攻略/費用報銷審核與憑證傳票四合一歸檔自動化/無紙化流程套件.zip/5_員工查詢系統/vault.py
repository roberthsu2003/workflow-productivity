# -*- coding: utf-8 -*-
"""薪資檔加密保管：以只有您知道的通關密語加密（AES-256-GCM，密語經 scrypt 衍生金鑰）。
加密後的 .enc 檔放在伺服器上，沒有通關密語的人（包含 MIS）無法讀取內容。
用法：
  python vault.py encrypt 薪資_202610.xlsx [--delete-original]   → 產生 薪資_202610.xlsx.enc
  python vault.py decrypt 薪資_202610.xlsx.enc 輸出檔.xlsx        → 還原（僅在您自己的電腦上使用）
通關密語請自行妥善保管；遺失將無法還原。建議另以密封方式交由董事長或財務長備援保管。
"""
import os, sys, getpass, argparse, secrets
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b"HRV1"

def _key(password, salt):
    return Scrypt(salt=salt, length=32, n=2**15, r=8, p=1).derive(password.encode("utf-8"))

def encrypt_bytes(data, password):
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    return MAGIC + salt + nonce + AESGCM(_key(password, salt)).encrypt(nonce, data, MAGIC)

def decrypt_bytes(blob, password):
    if blob[:4] != MAGIC: raise ValueError("不是 vault 加密檔")
    salt, nonce, ct = blob[4:20], blob[20:32], blob[32:]
    return AESGCM(_key(password, salt)).decrypt(nonce, ct, MAGIC)    # 密語錯誤或檔案被改動會丟出例外

def encrypt_file(src, password, delete_original=False):
    dst = src + ".enc"
    with open(src, "rb") as f: blob = encrypt_bytes(f.read(), password)
    with open(dst, "wb") as f: f.write(blob)
    if delete_original: os.remove(src)
    return dst

def ask_password(confirm=False, prompt="請輸入通關密語："):
    pw = getpass.getpass(prompt)
    if confirm and pw != getpass.getpass("再輸入一次確認："): sys.exit("兩次輸入不一致")
    if len(pw) < 12: sys.exit("通關密語至少 12 個字元，建議使用一句長句子")
    return pw

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("encrypt"); e.add_argument("file"); e.add_argument("--delete-original", action="store_true")
    d = sub.add_parser("decrypt"); d.add_argument("file"); d.add_argument("out")
    a = ap.parse_args()
    if a.cmd == "encrypt":
        print("完成：", encrypt_file(a.file, ask_password(confirm=True), a.delete_original))
    else:
        open(a.out, "wb").write(decrypt_bytes(open(a.file, "rb").read(), ask_password(prompt="通關密語：")))
        print("完成：", a.out)
