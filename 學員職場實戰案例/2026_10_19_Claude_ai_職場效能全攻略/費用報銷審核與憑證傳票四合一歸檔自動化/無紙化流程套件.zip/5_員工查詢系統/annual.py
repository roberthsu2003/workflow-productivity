# -*- coding: utf-8 -*-
"""年度薪資所得統計（供每年1月各類所得扣繳憑單與補充保費申報核對）。
用法：python annual.py --data data --year 2026 --out 年度統計_2026.xlsx
把 data 資料夾內該年度所有「薪資_YYYYMM.xlsx」彙總成 Excel（年度彙總、月明細、申報核對）。
本表為申報前核對用，格式代號與媒體申報格式請依國稅局、健保署最新規定，由會計確認後申報。
"""
import argparse
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
import hrdata

F = "Microsoft JhengHei"
HD = PatternFill("solid", fgColor="1F4E79"); TH = Side(style="thin", color="BFBFBF"); BD = Border(left=TH, right=TH, top=TH, bottom=TH)
COLS = ["給付月數", "薪資所得(應稅)", "其他兼職薪資", "給付總額(申報)", "扣繳稅額", "給付淨額", "免稅伙食費", "免稅加班費", "未休假薪資", "資遣費", "補充保費代扣", "勞退自願提繳", "勞保自付", "健保自付", "實領金額"]

def _head(ws, row, n):
    for c in range(1, n + 1):
        x = ws.cell(row, c); x.font = Font(name=F, bold=True, color="FFFFFF"); x.fill = HD; x.border = BD
        x.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

def build(data_dir, year, out, offset=0):
    data = hrdata.annual(data_dir, year, offset)
    if not data: raise SystemExit(f"{data_dir} 內找不到 {year} 年的薪資檔")
    wb = Workbook(); ws = wb.active; ws.title = "年度彙總"
    ws["A1"] = f"{year} 年度薪資所得統計"; ws["A1"].font = Font(name=F, bold=True, size=14, color="1F4E79")
    ws["A2"] = "申報前核對用；免稅伙食費上限與免稅加班費判斷為簡化計算，請會計確認；範例人名與身分證字號為虛構"; ws["A2"].font = Font(name=F, size=9, color="7F7F7F")
    heads = ["員工編號", "姓名", "身分證字號"] + COLS
    for i, h in enumerate(heads, 1): ws.cell(4, i, h)
    _head(ws, 4, len(heads))
    r = 5
    for eid, e in sorted(data.items()):
        vals = [eid, e["name"], e["idno"]] + [e["total"].get(k, 0) for k in COLS]
        for i, v in enumerate(vals, 1):
            c = ws.cell(r, i, v); c.font = Font(name=F, size=10); c.border = BD
            if i > 3: c.number_format = "#,##0;(#,##0);-"
        r += 1
    ws.cell(r, 1, "合計").font = Font(name=F, bold=True, size=10)
    for i in range(5, len(heads) + 1):
        L = ws.cell(4, i).column_letter
        c = ws.cell(r, i, f"=SUM({L}5:{L}{r-1})"); c.font = Font(name=F, bold=True, size=10); c.number_format = "#,##0;(#,##0);-"
    for i, w in enumerate([10, 12, 14] + [13] * len(COLS), 1): ws.column_dimensions[ws.cell(4, i).column_letter].width = w
    ws.freeze_panes = "D5"
    # 月明細
    wm = wb.create_sheet("月明細")
    mh = ["員工編號", "姓名", "月份"] + [k for k in COLS if k not in ("給付月數", "給付總額(申報)", "扣繳稅額", "給付淨額")]
    for i, h in enumerate(mh, 1): wm.cell(1, i, h)
    _head(wm, 1, len(mh)); r = 2
    for eid, e in sorted(data.items()):
        for mm, it in sorted(e["months"].items()):
            for i, v in enumerate([eid, e["name"], f"{year}/{mm}"] + [it.get(k, 0) for k in mh[3:]], 1):
                c = wm.cell(r, i, v); c.font = Font(name=F, size=10); c.border = BD
                if i > 3: c.number_format = "#,##0;(#,##0);-"
            r += 1
    for i in range(1, len(mh) + 1): wm.column_dimensions[wm.cell(1, i).column_letter].width = 13
    wm.freeze_panes = "D2"
    # 申報核對
    wc = wb.create_sheet("申報核對")
    notes = [
        ("各類所得扣繳憑單（薪資所得）", "每月扣繳稅款須於給付日次月10日前繳納；憑單原則上於次年1月31日前申報、2月10日前填發（遇連續3日以上國定假日依規定順延）。「給付總額、扣繳稅額、給付淨額」見年度彙總。"),
        ("補充保費", "依健保署規定按月扣取與繳納（獎金累計超過當月投保金額4倍部分、符合條件之兼職薪資等），年度彙總見「補充保費代扣」欄，申報格式請依健保署規定。"),
        ("免稅項目", "伙食費每月免稅上限、加班費免稅（須符合勞基法標準並在每月延長工時上限內）為簡化計算，請會計核對。"),
        ("勞退自願提繳", "雇主提繳與員工自願提繳（6%以內）的所得稅處理，請依最新規定核對，員工報稅時可參考此欄。"),
        ("未休假薪資、資遣費", "特休未休工資屬薪資所得；資遣費超過免稅額度的部分須課稅，請會計確認。"),
        ("保存", "年度統計與工資清冊、扣繳憑單相關資料請依規定保存，涉及個資須限制存取。")]
    wc["A1"] = "申報核對提醒"; wc["A1"].font = Font(name=F, bold=True, size=14, color="1F4E79")
    for i, (a, b) in enumerate(notes, 3):
        wc.cell(i, 1, a).font = Font(name=F, bold=True, size=10); c = wc.cell(i, 2, b); c.font = Font(name=F, size=10); c.alignment = Alignment(wrap_text=True, vertical="top")
    wc.column_dimensions["A"].width = 30; wc.column_dimensions["B"].width = 110
    wb.save(out); return out

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--data", default="data"); ap.add_argument("--year", required=True); ap.add_argument("--out", required=True); ap.add_argument("--pay-offset", type=int, default=0, help="0=薪資當月發放，1=次月發放（所得以給付年度認列）")
    a = ap.parse_args(); print("完成：", build(a.data, a.year, a.out, a.pay_offset))
