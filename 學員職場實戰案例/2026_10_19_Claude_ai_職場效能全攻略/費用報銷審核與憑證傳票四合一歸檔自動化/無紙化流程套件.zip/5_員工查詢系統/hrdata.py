# -*- coding: utf-8 -*-
"""讀取薪資總表 Excel（需已在 Excel 重新計算並存檔，以便讀到公式結果）。"""
import os, re, io, datetime
from openpyxl import load_workbook as _lw
import vault

_PW = None          # 通關密語只存在記憶體，不寫入任何檔案
_CACHE = {}         # {(路徑, 修改時間): 解析結果}，僅存記憶體

def set_passphrase(pw):
    global _PW; _PW = pw; _CACHE.clear()

def _need_pw():
    global _PW
    if _PW is None: _PW = vault.ask_password(prompt="薪資檔已加密，請輸入通關密語：")
    return _PW

def load_workbook(path, data_only=True):
    """一般 .xlsx 直接開；.enc 在記憶體內解密，不產生暫存檔。"""
    if path.endswith(".enc"):
        data = vault.decrypt_bytes(open(path, "rb").read(), _need_pw())
        return _lw(io.BytesIO(data), data_only=data_only)
    return _lw(path, data_only=data_only)

MONTH_SHEET, QUERY_SHEET, LEAVE_SHEET = "流程1_月結表", "流程1_特休與請假查詢", "流程1_請假申請"
ADD_ITEMS = [("本薪", "本薪"), ("績效獎金", "績效獎金"), ("加班費", "加班費"), ("伙食費", "伙食費"),
             ("資遣費", "資遣費"), ("未休假薪資", "未休假薪資"), ("其他(兼職)", "其他(兼職)")]
SUB_ITEMS = [("病假扣款", "病假扣款"), ("遲到扣款", "遲到扣款"), ("事假扣款", "事假扣款"), ("薪資扣繳", "薪資扣繳"),
             ("獎金扣繳", "獎金扣繳"), ("勞保自付額", "勞保代扣"), ("勞保補〈退〉", "勞保補〈退〉"),
             ("健保自付額", "健保代扣"), ("健保補〈退〉", "健保補〈退〉"), ("勞退自願提繳", "勞退代扣"),
             ("補充保險費", "補充保險費代扣"), ("其他代扣款", "其他代扣款")]

def _num(v):
    return v if isinstance(v, (int, float)) else 0

def list_months(data_dir):
    out = []
    for f in os.listdir(data_dir):
        m = re.fullmatch(r"薪資_(\d{6})\.xlsx(\.enc)?", f)
        if m: out.append(m.group(1))
    return sorted(set(out), reverse=True)

def month_path(data_dir, ym):
    if not re.fullmatch(r"\d{6}", ym): return None
    for ext in (".xlsx.enc", ".xlsx"):
        p = os.path.join(data_dir, f"薪資_{ym}{ext}")
        if os.path.exists(p): return p
    return None

def ym_label(ym):
    return f"{ym[:4]} 年 {int(ym[4:])} 月"

def load_employees(path):
    """回傳 {員編: 記錄}（同一檔案未變動時使用記憶體快取）。"""
    key = (path, os.path.getmtime(path))
    if key not in _CACHE: _CACHE[key] = _load_employees(path)
    import copy
    return copy.deepcopy(_CACHE[key])

def _load_employees(path):
    wb = load_workbook(path, data_only=True)
    ws = wb[MONTH_SHEET]
    hdr = {}
    for c in range(1, ws.max_column + 1):
        v = ws.cell(5, c).value
        if v: hdr.setdefault(v, []).append(c)
    def get(row, name, last=False):
        cols = hdr.get(name)
        return ws.cell(row, cols[-1 if last else 0]).value if cols else None
    emps = {}
    r = 6
    while ws.cell(r, hdr["姓名"][0]).value:
        eid = str(get(r, "員工編號") or "").strip()
        rec = {"empid": eid, "name": get(r, "姓名"), "idno": str(get(r, "身分證字號") or "").strip().upper(),
               "add": [], "sub": []}
        for label, h in ADD_ITEMS:
            rec["add"].append((label, _num(get(r, h, last=(h in ("本薪", "伙食費"))))))
        for label, h in SUB_ITEMS:
            rec["sub"].append((label, _num(get(r, h))))
        rec["raw"] = {h: ws.cell(r, cols[-1]).value for h, cols in hdr.items()}
        rec["add_total"] = _num(get(r, "加項金額")); rec["sub_total"] = _num(get(r, "減項金額")); rec["net"] = _num(get(r, "實領金額"))
        rec["ot_hours"] = _num(get(r, "加班時數合計")); rec["leave_days"] = _num(get(r, "請假日數"))
        emps[eid] = rec; r += 1
    # 特休與請假累計
    leave_info = {}
    if QUERY_SHEET in wb.sheetnames:
        q = wb[QUERY_SHEET]
        heads = [q.cell(4, c).value for c in range(1, q.max_column + 1)]
        for rr in range(5, 35):
            eid = q.cell(rr, 1).value
            if not eid: continue
            d = {heads[c - 1]: q.cell(rr, c).value for c in range(1, len(heads) + 1)}
            leave_info[str(eid)] = {
                "hire": d.get("到職日"), "entitled": _num(d.get("曆年應有特休(按比例,日)")), "carry_in": _num(d.get("上年度遞延至本年(日)")),
                "total": _num(d.get("本年度可休合計")), "used": _num(d.get("已休特休(日)")), "remain": _num(d.get("剩餘特休(日)")),
                "defer_out": _num(d.get("本年度再遞延至次年(日)")), "settle": d.get("結算類別") or "",
                "settle_days": _num(d.get("遞延日數未休(折發日)")) + _num(d.get("本年度未休(折發日)")), "settle_amount": _num(d.get("應折發未休特休工資")),
                "types": [(k.replace("（已休日）", ""), _num(v)) for k, v in d.items() if k.endswith("（已休日）") and _num(v)],
                "sick_remain": _num(d.get("病假剩餘(日,以30日計)")), "pers_remain": _num(d.get("事假剩餘(日,以14日計)"))}
    # 請假紀錄
    records = {}
    if LEAVE_SHEET in wb.sheetnames:
        l = wb[LEAVE_SHEET]
        for rr in range(5, 65):
            name = l.cell(rr, 4).value
            if not name: continue
            fmt = lambda v: v.strftime("%Y-%m-%d") if isinstance(v, (datetime.date, datetime.datetime)) else (v or "")
            records.setdefault(name, []).append({"id": l.cell(rr, 1).value, "type": l.cell(rr, 6).value, "start": fmt(l.cell(rr, 7).value),
                "end": fmt(l.cell(rr, 8).value), "days": _num(l.cell(rr, 9).value), "agent": l.cell(rr, 11).value or "",
                "status": l.cell(rr, 13).value or ""})
    roster = {}
    if LEAVE_SHEET in wb.sheetnames:
        l = wb[LEAVE_SHEET]
        for rr in range(5, 35):
            eid = l.cell(rr, 20).value
            if eid: roster[str(eid)] = {"zhenghao": str(l.cell(rr, 25).value or "0").strip(), "addr": str(l.cell(rr, 26).value or "").strip()}
    for eid, rec in emps.items():
        rec["leave"] = leave_info.get(eid); rec["records"] = records.get(rec["name"], [])
        rec["zhenghao"] = roster.get(eid, {}).get("zhenghao", "0"); rec["addr"] = roster.get(eid, {}).get("addr", "")
    return emps


# ---------------- 年度統計（供一月各類所得與補充保費申報、員工報稅參考）----------------
MEAL_EXEMPT_CAP = 3000      # 免稅伙食費每月上限（請會計確認當年度規定）
OT_EXEMPT_HOURS = 46        # 免稅加班費對應之每月延長工時上限（需符合勞基法標準）

def year_files(data_dir, year, offset=0):
    """回傳給付年度為 year 的月份檔 [(YYYYMM, 路徑)]；offset=1 表示次月發薪。"""
    byname = {}
    for f in sorted(os.listdir(data_dir)):
        m = re.fullmatch(r"薪資_(\d{6})\.xlsx(\.enc)?", f)
        if m and pay_year(m.group(1), offset) == int(year):
            p = os.path.join(data_dir, f)
            if m.group(1) not in byname or p.endswith(".enc"): byname[m.group(1)] = p
    return sorted(byname.items())

def _g(raw, k):
    return _num(raw.get(k))

def month_tax_items(rec):
    """單月：把月結表資料分成應稅薪資、免稅項目、扣繳與保費。"""
    raw = rec["raw"]
    ot_pay, ot_h = _g(raw, "加班費"), _g(raw, "加班時數合計")
    ot_exempt = ot_pay if ot_h <= OT_EXEMPT_HOURS else round(ot_pay * OT_EXEMPT_HOURS / ot_h)
    meal = _g(raw, "伙食費"); meal_exempt = min(meal, MEAL_EXEMPT_CAP)
    taxable_base = _g(raw, "應稅所得") - ot_exempt              # 本薪、績效獎金、扣款後，不含免稅加班費
    return {"薪資所得(應稅)": taxable_base + (meal - meal_exempt) + _g(raw, "未休假薪資"),
            "其他兼職薪資": _g(raw, "其他(兼職)"), "免稅加班費": ot_exempt, "免稅伙食費": meal_exempt,
            "資遣費": _g(raw, "資遣費"), "未休假薪資": _g(raw, "未休假薪資"),
            "薪資扣繳": _g(raw, "薪資扣繳"), "獎金扣繳": _g(raw, "獎金扣繳"), "補充保費代扣": _g(raw, "補充保險費代扣"),
            "勞退自願提繳": _g(raw, "勞退代扣"), "勞保自付": _g(raw, "勞保代扣"), "健保自付": _g(raw, "健保代扣"),
            "實領金額": rec["net"]}

def annual(data_dir, year, offset=0):
    """回傳 {員編: {name, idno, months:{月:項目dict}, total:項目dict}}"""
    res = {}
    for mm, path in year_files(data_dir, year, offset):
        for eid, rec in load_employees(path).items():
            e = res.setdefault(eid, {"name": rec["name"], "idno": rec["idno"], "months": {}, "total": {}})
            items = month_tax_items(rec); e["months"][mm] = items
            for k, v in items.items(): e["total"][k] = e["total"].get(k, 0) + v
    for e in res.values():
        t = e["total"]; t["給付總額(申報)"] = t.get("薪資所得(應稅)", 0) + t.get("其他兼職薪資", 0)
        t["扣繳稅額"] = t.get("薪資扣繳", 0) + t.get("獎金扣繳", 0); t["給付淨額"] = t["給付總額(申報)"] - t["扣繳稅額"]
        t["給付月數"] = len(e["months"])
    return res


def load_config(path):
    """讀取「申報設定」工作表，回傳 {代碼: 設定值(字串)}。"""
    wb = load_workbook(path, data_only=True)
    ws = wb["申報設定"]; cfg = {}
    for r in range(5, 40):
        k = ws.cell(r, 4).value
        if k: cfg[str(k)] = "" if ws.cell(r, 2).value is None else str(ws.cell(r, 2).value).strip()
    return cfg

def pay_year(ym, offset):
    """薪資所屬年月 → 給付年度（所得以給付日認列）。ym 例如 '202612'。"""
    y, m = int(ym[:4]), int(ym[4:])
    return y + (1 if m + int(offset) > 12 else 0)
