# -*- coding: utf-8 -*-
"""產生三個流程的「範例完成檔」。所有資料皆為範例。也可改寫成正式的傳票／請款單版面。"""
import os, sys
from reportlab.lib.units import mm
from reportlab.platypus import Paragraph, Spacer
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
import packet as P

XLSX = sys.argv[1] if len(sys.argv) > 1 else "../1_素材/無紙化流程_素材總表.xlsx"
OUT = sys.argv[2] if len(sys.argv) > 2 else "../2_完成檔案"
FONT = sys.argv[3] if len(sys.argv) > 3 else None
P.register_font(FONT); S = P.styles(); T = "_tmp_samples"; os.makedirs(T, exist_ok=True); os.makedirs(OUT, exist_ok=True)
CO = "文創科技股份有限公司"

def kv(rows, w=(38*mm, 118*mm)):
    return P.grid(rows, list(w), header=False)

# ---------- 流程2 ----------
def voucher():
    d = [["傳票編號", "VCH-202610-0088", "傳票日期", "2026-10-09"],
         ["摘要", "範例員工A 客戶拜訪計程車資（EXP-202610-001）", "", ""]]
    ent = [["借/貸", "會計科目", "科目代號", "借方金額", "貸方金額"],
           ["借", "交通費", "6470", "952", ""],
           ["借", "進項稅額", "119304", "48", ""],
           ["貸", "應付費用--員工", "215002", "", "1,000"],
           ["合計", "", "", "1,000", "1,000"]]
    st = [Paragraph("會計傳票", S["h1"]), Paragraph(f"{CO}　範例資料", S["sub"]), Spacer(1, 8),
          P.grid(d, [24*mm, 80*mm, 24*mm, 28*mm], header=False), Spacer(1, 10),
          P.grid(ent, [18*mm, 52*mm, 30*mm, 28*mm, 28*mm]), Spacer(1, 30),
          Paragraph("製表：財務會計　　覆核：CFO　　核准：CEO", S["body"])]
    P.build(st, f"{T}/voucher.pdf")

def claim():
    rows = [["申請編號", "EXP-202610-001"], ["公司別", "文創科技股份有限公司"], ["申請人／部門", "範例員工A／企劃部"],
            ["申請日期", "2026-10-08"], ["會計科目", "6470 交通費"], ["憑證", "電子發票　日期 2026-10-07　統編 12345678　範例運輸股份有限公司"],
            ["未稅／稅額／含稅", "952 ／ 48 ／ 1,000"], ["用途說明", "客戶拜訪計程車資"], ["預定付款日", "2026-11-05"]]
    sig = [["申請人", "財務會計", "CFO", "CEO"],
           ["範例員工A\n2026-10-08", "財務會計\n2026-10-08", "CFO\n2026-10-09", "CEO\n2026-10-09"]]
    sig = [[c.replace("\n", "<br/>") for c in r] for r in sig]
    st = [Paragraph("費用報銷請款單（已簽核）", S["h1"]), Paragraph(f"{CO}　範例資料", S["sub"]), Spacer(1, 8),
          kv(rows), Spacer(1, 16), P.grid(sig, [39*mm]*4)]
    P.build(st, f"{T}/claim.pdf")

def draw_receipt(path, lines, stamp_txt):
    c = canvas.Canvas(path, pagesize=A4); w, h = A4
    c.setFont(P.FN, 16); c.drawString(30*mm, h-30*mm, lines[0])
    c.setFont(P.FN, 11)
    for i, t in enumerate(lines[1:]): c.drawString(30*mm, h-(42+i*8)*mm, t)
    c.setStrokeColor(colors.HexColor("#C00000")); c.setFillColor(colors.HexColor("#C00000"))
    c.circle(150*mm, h-100*mm, 16*mm); c.setFont(P.FN, 10); c.drawCentredString(150*mm, h-101*mm, stamp_txt)
    c.setFillColor(colors.grey); c.setFont(P.FN, 8); c.drawString(30*mm, 25*mm, "（範例影像，非真實憑證）")
    c.save()

# ---------- 流程3 ----------
def seal_form():
    rows = [["申請編號", "SEAL-202610-001"], ["公司別", "文創科技股份有限公司"], ["文件類型／名稱", "合約／範例合作備忘錄"],
            ["對方單位", "範例股份有限公司"], ["合約期間", "2026-10-13 至 2027-10-12（1年0個月）　自動續約：否"],
            ["說明", "雙方就範例專案合作之原則性約定；不含保密與競業條款"], ["關鍵字", "合作;備忘錄;範例股份有限公司"], ["用印種類", "公司大章"], ["申請人／日期", "範例員工B／2026-10-12"],
            ["用印日期／用印人", "2026-10-13／行政"], ["歸檔編號", "2026-C-001"]]
    P.build([Paragraph("用印申請單", S["h1"]), Paragraph(f"{CO}　範例資料", S["sub"]), Spacer(1, 8), kv(rows)], f"{T}/seal_form.pdf")

# ---------- 流程1 ----------
def payroll():
    from openpyxl import load_workbook
    wbk = load_workbook(XLSX, data_only=True)
    ws = wbk["流程1_月結表"]
    hdr = {}
    for c in range(1, ws.max_column + 1):
        v = ws.cell(5, c).value
        if v and v not in hdr: hdr[v] = c
    f = lambda v: f"{int(v or 0):,}" if isinstance(v, (int, float)) else (v or "")
    rows = [["姓名", "本薪", "加班費", "應計薪資", "減項金額", "實領金額"]]
    for r in range(6, 10):
        n = ws.cell(r, hdr["姓名"]).value or "合計"
        rows.append([n] + [f(ws.cell(r, hdr[h]).value) for h in ("本薪", "加班費", "應計薪資", "減項金額", "實領金額")])
    P.build([Paragraph("薪資月結彙總（2026 年 10 月）", S["h1"]), Paragraph(f"{CO}　範例資料", S["sub"]), Spacer(1, 8),
             P.grid(rows, [34*mm, 28*mm, 26*mm, 30*mm, 28*mm, 28*mm])], f"{T}/payroll.pdf")
    v = wbk["流程1_傳票彙總"]
    ent = [["科目代號", "會計科目", "借方金額", "貸方金額", "摘要"]]
    g = lambda x: f"{x:,.2f}" if isinstance(x, (int, float)) and x else ""
    r = 5
    while v.cell(r, 2).value:
        if (v.cell(r, 3).value or 0) or (v.cell(r, 4).value or 0):
            ent.append([v.cell(r, 1).value, v.cell(r, 2).value, g(v.cell(r, 3).value), g(v.cell(r, 4).value), v.cell(r, 5).value or ""])
        r += 1
    P.build([Paragraph("薪資傳票", S["h1"]), Paragraph("拋轉金城資訊用　範例資料", S["sub"]), Spacer(1, 8),
             P.grid(ent, [20*mm, 38*mm, 26*mm, 26*mm, 66*mm])], f"{T}/payroll_voucher.pdf")

voucher(); claim(); seal_form(); payroll()
draw_receipt(f"{T}/receipt.pdf", ["電子發票證明聯（範例）", "發票號碼：AB-12345678", "日期：2026-10-07", "賣方：範例運輸股份有限公司　統編 12345678", "品項：計程車資　1 趟", "銷售額 952　稅額 48　總計 1,000"], "範例")
draw_receipt(f"{T}/contract.pdf", ["範例合作備忘錄（定稿）", "甲方：文創科技股份有限公司", "乙方：範例股份有限公司", "本備忘錄為範例內容，僅供流程示意。", "雙方同意就範例專案進行合作。"], "待用印")
draw_receipt(f"{T}/contract_scan.pdf", ["範例合作備忘錄（用印後掃描）", "甲方：文創科技股份有限公司", "乙方：範例股份有限公司", "用印日期：2026-10-13", "用印種類：公司大章"], "公司大章")

P.merge("EXP-202610-001", "費用報銷歸檔資料", [("會計傳票", f"{T}/voucher.pdf"), ("已簽核請款單", f"{T}/claim.pdf"), ("簽核歷程", "@trail"), ("發票／憑證附件", f"{T}/receipt.pdf")], f"{OUT}/流程2_費用報銷_合併列印範例.pdf", XLSX, T)
P.merge("SEAL-202610-001", "用印申請歸檔資料", [("用印申請單", f"{T}/seal_form.pdf"), ("簽核歷程", "@trail"), ("文件定稿", f"{T}/contract.pdf"), ("用印後掃描檔", f"{T}/contract_scan.pdf")], f"{OUT}/流程3_用印申請_歸檔範例.pdf", XLSX, T)
P.merge("PAY-202610", "2026年10月薪資歸檔資料", [("薪資月結彙總", f"{T}/payroll.pdf"), ("薪資傳票", f"{T}/payroll_voucher.pdf"), ("簽核歷程", "@trail")], f"{OUT}/流程1_薪資傳票_歸檔範例.pdf", XLSX, T)
print("done")
